const express = require("express");
const router = express.Router();
const AddItem = require("../models/addItemModel");
const multer = require("multer");
const bodyParser = require("body-parser");
const fs = require("fs");
const path = require("path");
router.use(express.static(__dirname + "./products"));
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({ extended: false }));
router.get("/", (req, res) => {
  AddItem.find({}, (err, data) => {
    res.json(data);
  });
});
const storage = multer.diskStorage({
  destination: "./products/photos",
  filename: (req, photos, cb) => {
    cb(
      null,
      photos.fieldname + "_" + Date.now() + path.extname(photos.originalname)
    );
  },
});

const upload = multer({ storage: storage }).array("photos", 5);
router.post("/", upload, (req, res, next) => {
  console.log(req.body);
  console.log(req.files);
});
// router.post("/", (req, res) => {
//   addItem = new AddItem({
//     photos: req.body.photos,
//     title: req.body.title,
//     titleDescription: req.body.titleDescription,
//     summary: req.body.summary,
//     description: req.body.description,
//     selectACategory: req.body.selectACategory,
//     areasOfDelivery: req.body.areasOfDelivery,
//     selectShops: req.body.selectShops,
//     selectWeights: req.body.selectWeights,
//     egg: req.body.egg,
//     eggless: req.body.eggless,
//     serviceablePincode: req.body.serviceablePincode,
//     suggestiontoBuy: req.body.suggestiontoBuy,
//     priceTaxExcluded: req.body.priceTaxExcluded,
//     priceTaxIncluded: req.body.priceTaxIncluded,
//     taxSlab: req.body.taxSlab,
//     quantity: req.body.quantity,
//     itemEmptyAlert: req.body.itemEmptyAlert,
//     seoMetaTitle: req.body.seoMetaTitle,
//     seoMetaDesc: req.body.seoMetaDesc,
//     seoKeywords: req.body.seoKeywords,
//   });

//   addItem.save(() => {
//     res.json("Success");
//   });
// });
module.exports = router;
