const express = require("express");
const router = express.Router();
const AddItem = require("../models/addItemModel");
router.get("/", (req, res) => {
  AddItem.find({}, (err, data) => {
    res.json(data);
  });
});
router.post("/", (req, res) => {
  console.log(req.body);
});

module.exports = router;
