const mongoose = require("mongoose");
const Schema = mongoose.Schema;
newItemSchema = new Schema({
  photos: [String],
  title: String,
  titleDescription: String,
  summary: String,
  description: String,
  selectACategory: [String],
  areasOfDelivery: [String],
  selectShops: [String],
  selectWeights: [Number],
  egg: Boolean,
  eggless: Boolean,
  serviceablePincode: [Number],
  suggestiontoBuy: [String],
  priceTaxExcluded: Number,
  priceTaxIncluded: Number,
  taxSlab: Number,
  quantity: Number,
  itemEmptyAlert: Number,
  seoMetaTitle: String,
  seoMetaDesc: String,
  seoKeywords: String,
});
module.exports = mongoose.model("newItem", newItemSchema);
