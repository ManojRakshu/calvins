const express = require("express");
const mongoose = require("mongoose");
mongoose.connect(
  "asdf", //mongodburl
  { useNewUrlParser: true, useUnifiedTopology: true }
);

const app = express();
const cors = require("cors");
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use("/newItem", require("./routes/addItem"));
const port = process.env.PORT | 80;

app.listen(port);
